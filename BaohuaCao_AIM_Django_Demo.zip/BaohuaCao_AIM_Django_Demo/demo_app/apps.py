from django.apps import AppConfig


class DemoAppConfig(AppConfig):
    name = 'demo_app'
