from django.urls import path

from . import views


urlpatterns = [
    path('', views.IndexView.as_view(), name='index'),
    path('date_view/<str:date>/', views.date_view, name='date_view'),
    path('publisher_view/<int:publisher>/<str:date>/', views.publisher_view, name='publisher_view')
    ]